final class OpponentAwareness {
    Pos lastKnown;
    double memoryTime;
    int observedUpAttacks, observedDownAttacks, observedUpBlocks, observedDownBlocks,
            lastObservedAttackSequence = -1, lastObservedBlockSequence = -1;
    boolean visible;

    OpponentAwareness(Pos pos, boolean visible) {
        lastKnown = pos;
        this.visible = visible;
        memoryTime = visible ? 1 : 0;
    }
}
